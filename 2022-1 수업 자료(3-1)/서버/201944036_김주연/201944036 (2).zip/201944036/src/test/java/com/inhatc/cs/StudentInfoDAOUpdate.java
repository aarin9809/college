package com.inhatc.cs;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.inhatc.domain.StudentVO;
import com.inhatc.persistence.StudentInfoDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})

public class StudentInfoDAOUpdate {
	
	@Inject
	private StudentInfoDAO dao;
	
	@Test
	public void update() throws Exception {
		StudentVO vo = new StudentVO();
		vo.setStudentid("201944037");
		vo.setStudentname("아무개");
		vo.setAddress("발리");
		vo.setPhone("01022228888");;
		vo.setEmail("moooo@naver.com");
		vo.setEmail("naver.com");
		dao.update(vo);
	}
}
