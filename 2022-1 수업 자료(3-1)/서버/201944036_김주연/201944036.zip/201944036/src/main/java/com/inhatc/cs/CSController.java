package com.inhatc.cs;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

@Controller
public class CSController {
	
	@RequestMapping("doA")
	public void doA() {
		int i = 1;
		int sum = 0;
		 for (i = 1; i <= 10; i++) {
			 sum += i;
			 System.out.println("sum: " + i + "\n");
		 }
	}
	
	@RequestMapping("doB")
	public void doB() {
		System.out.println("doB Called~~~");
	}
}
