package com.inhatc.domain;

public class MovieVO {
	private int movieid ;
	private String moviecategory ;
	private String moviename ;
	private int movieprice ;
	private String moviesit ;
		
	public int getMovieid() {
		return movieid;
	}

	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}

	public String getMoviecategory() {
		return moviecategory;
	}

	public void setMoviecategory(String moviecategory) {
		this.moviecategory = moviecategory;
	}

	public String getMoviename() {
		return moviename;
	}

	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}

	public int getMovieprice() {
		return movieprice;
	}

	public void setMovieprice(int movieprice) {
		this.movieprice = movieprice;
	}

	public String getMoviesit() {
		return moviesit;
	}

	public void setMoviesit(String moviesit) {
		this.moviesit = moviesit;
	}

	
	@Override
	public String toString() {
		return "MovieVO [movieid=" + movieid + ", moviecategory=" + moviecategory + ", moviename=" + moviename
				+ ", movieprice=" + movieprice + ", moviesit=" + moviesit + "]";
	}

	public MovieVO(int movieid, String moviecategory, String moviename, int movieprice, String moviesit) {
		super();
		this.movieid = movieid;
		this.moviecategory = moviecategory;
		this.moviename = moviename;
		this.movieprice = movieprice;
		this.moviesit = moviesit;
	}

	public MovieVO() {
		super();
	}
}
