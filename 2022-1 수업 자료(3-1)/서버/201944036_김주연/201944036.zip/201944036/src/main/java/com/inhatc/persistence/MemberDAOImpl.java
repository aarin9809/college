package com.inhatc.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.inhatc.domain.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {
	
	@Inject
	private  SqlSession sqlSession;
	private static String namespace="com.inhatc.mapper.MemberMapper";
	
	@Override
	public String getTime() {
		return sqlSession.selectOne(namespace + ".getTime");
	}
	
	@Override
	public void insertMember(MemberVO vo) {
		sqlSession.insert(namespace + ".insertMember", vo);
	}
	
	@Override
	public MemberVO readMember(String userid) throws Exception {
		return (MemberVO)sqlSession.selectOne(namespace + ".readMember", userid);
	}
	
	@Override
	public MemberVO readMemberWithPW(String userid, String userpw) throws Exception {
		Map<String, Object> parseMap = new HashMap<String, Object>();
		parseMap.put("userid", userid);
		parseMap.put("userpw", userpw);
		return (MemberVO)sqlSession.selectOne(namespace + ".readMemberWithPW", parseMap);
	}
	
	@Override
	public void update(MemberVO vo) throws Exception {
		sqlSession.update(namespace + ".update", vo);
	}
	
	@Override
	public void delete(String userid) throws Exception {
		sqlSession.delete(namespace + ".delete", userid);
	}
	
	@Override
	public int countAll() throws Exception {
		return sqlSession.selectOne(namespace + ".countAll");
	}
	
	@Override
	public List<MemberVO> listAll() throws Exception {
		return sqlSession.selectList(namespace + ".listAll");
	}
}
