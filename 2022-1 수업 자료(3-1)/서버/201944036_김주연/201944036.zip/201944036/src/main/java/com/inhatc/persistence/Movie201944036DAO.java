package com.inhatc.persistence;

import java.util.List;

import com.inhatc.domain.MovieVO;

public interface Movie201944036DAO {
	public void insertMovie(MovieVO vo) throws Exception;
	public MovieVO readMovie(int movieid) throws Exception;
	public void update(MovieVO vo) throws Exception;
	public List<MovieVO> listMovie() throws Exception;
	public void delete(int movieid) throws Exception;
	public int countMovie() throws Exception;

}