package com.inhatc.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.inhatc.domain.MovieVO;

@Repository
public class Movie201944036DAOImpl implements Movie201944036DAO {
	
	@Inject
	private  SqlSession sqlSession;
	private static String namespace="com.inhatc.mapper.Movie201944036Mapper";
	
	@Override
	public void insertMovie(MovieVO vo) throws Exception {
		sqlSession.insert(namespace + ".insertMovie", vo);
	}
	
	@Override
	public MovieVO readMovie (int movieid) throws Exception {
		return (MovieVO)sqlSession.selectOne(namespace + ".readMovie", movieid);
	}
	
	@Override
	public void update(MovieVO vo) throws Exception {
		sqlSession.update(namespace + ".update", vo);
	}
	
	@Override
	public void delete(int movieid) throws Exception {
		sqlSession.delete(namespace + ".delete", movieid);
	}
	
	@Override
	public int countMovie() throws Exception {
		return sqlSession.selectOne(namespace + ".countMovie");
	}
	
	@Override
	public List<MovieVO> listMovie() throws Exception {
		return sqlSession.selectList(namespace + ".listMovie");
	}
	
}
