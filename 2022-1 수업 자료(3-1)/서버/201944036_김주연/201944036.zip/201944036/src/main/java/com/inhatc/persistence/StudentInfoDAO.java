package com.inhatc.persistence;

import java.util.List;

import com.inhatc.domain.StudentVO;

public interface StudentInfoDAO {
	public void insertStudent(StudentVO vo) throws Exception;
	public StudentVO readStudent(String studentid) throws Exception;
	public void update(StudentVO vo) throws Exception;
	public List<StudentVO> listStudent() throws Exception;
	public void delete(String studentid) throws Exception;
	public int countStudent() throws Exception;

}