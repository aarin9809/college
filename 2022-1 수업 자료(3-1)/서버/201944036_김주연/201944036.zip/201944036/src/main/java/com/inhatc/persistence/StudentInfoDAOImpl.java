package com.inhatc.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.inhatc.domain.StudentVO;

@Repository
public class StudentInfoDAOImpl implements StudentInfoDAO {
	
	@Inject
	private  SqlSession sqlSession;
	private static String namespace="com.inhatc.mapper.StudentInfoMapper";
	
	@Override
	public void insertStudent(StudentVO vo) throws Exception {
		sqlSession.insert(namespace + ".insertStudent", vo);
	}
	
	@Override
	public StudentVO readStudent (String studentid) throws Exception {
		return (StudentVO)sqlSession.selectOne(namespace + ".readStudent", studentid);
	}
	
	@Override
	public void update(StudentVO vo) throws Exception {
		sqlSession.update(namespace + ".update", vo);
	}
	
	@Override
	public void delete(String studentid) throws Exception {
		sqlSession.delete(namespace + ".delete", studentid);
	}
	
	@Override
	public int countStudent() throws Exception {
		return sqlSession.selectOne(namespace + ".countStudent");
	}
	
	@Override
	public List<StudentVO> listStudent() throws Exception {
		return sqlSession.selectList(namespace + ".listStudent");
	}
	
}
