package com.inhatc.cs;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.inhatc.domain.MovieVO;
import com.inhatc.persistence.Movie201944036DAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})

public class MovieDAOInsert {
	
	@Inject
	private Movie201944036DAO dao;
	
	@Test
	public void insertMovie() throws Exception{
		MovieVO vo = new MovieVO();
		vo.setMovieid(3);
		vo.setMoviecategory("애니");
		vo.setMoviename("명탐정코난:비색의탄환");
		vo.setMovieprice(20000);
		vo.setMoviesit("D관 8열 15번");
		dao.insertMovie(vo);
	}
}
