package com.inhatc.cs;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.inhatc.domain.StudentVO;
import com.inhatc.persistence.StudentInfoDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})

public class StudentInfoDAOInsert {
	
	@Inject
	private StudentInfoDAO dao;
	
	@Test
	public void testInsertStudent() throws Exception{
		StudentVO vo = new StudentVO();
		vo.setStudentid("201944040");
		vo.setStudentname("최주연");
		vo.setAddress("뉴욕시");
		vo.setPhone("01011119999");
		vo.setEmail("choi@gmail.com");
		dao.insertStudent(vo);
	}
}
