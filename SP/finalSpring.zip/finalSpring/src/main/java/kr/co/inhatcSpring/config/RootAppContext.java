package kr.co.inhatcSpring.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootAppContext {

}
