package kr.co.inhatcspring.beans;

public class Notice {

}
