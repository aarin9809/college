package kr.co.inhatcspring.mapper;

public interface DepartmentInfoMapper {

}
