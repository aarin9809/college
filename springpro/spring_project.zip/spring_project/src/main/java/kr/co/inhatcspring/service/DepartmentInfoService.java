package kr.co.inhatcspring.service;

public class DepartmentInfoService {

}
